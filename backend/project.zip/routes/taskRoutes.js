const express = require("express");

const createTask = require("../controllers/taskController");
const validateToken = require("../middleware/validatetokenhandler")

const router = express.Router();

router.post("/createtask",validateToken,createTask);

module.exports = router;
